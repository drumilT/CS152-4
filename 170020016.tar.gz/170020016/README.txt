In order of Marks increased-

Q5) I considered that we would get only expressions, so didn't put a case for single leaf.
	Adding that and a small change for recursive call it works.
Q3) Had to make slight change in helper2 defination to make it work, I was using the prior score as well which was creating the problem 
Q4b) Just had to complete one fuction defination of red1 and 2. 
Q2) Used simple expt , had to use modulus expt , please consider for partials
